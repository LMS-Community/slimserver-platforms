<html>
    <head>
        <title>Example</title>
    </head>
    <body>
        <?php echo $_POST["text_value"]; ?>
    </body>
</html>
